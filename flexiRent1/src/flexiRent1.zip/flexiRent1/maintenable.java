/**
 * 
 */
package flexiRent1;


public interface maintenable {
	
	 boolean performMaintenance();
	
	 boolean completeMaintenance(DateTime completionDate);
	
}
