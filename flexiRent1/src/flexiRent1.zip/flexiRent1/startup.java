/**

 * 
 */
package flexiRent1;
/**
 *
 */

public class startup {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		flexiRentsystem obj = new flexiRentsystem();
		obj.flexiMenu();
	}

}
