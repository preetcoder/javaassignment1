Assumptions :

Property is name of my rentalproperty class.

Add Property:

A for Apartment and PS for Premium Suite

Property ID is A_streetno_streetname_suburb without spaces

Setting last maintenance date for apartment as date on which i am adding property.

Setting my property rent status as available when i add a new property.


